package com.datajpa.restapi.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.datajpa.restapi.server.Employee;
@Repository
public class EmployeeDAO {
	
	private List<Employee> elist = new ArrayList();
	public EmployeeDAO() {
		elist.add(new Employee(101, "Scott"));
		elist.add(new Employee(102, "Smith"));
		elist.add(new Employee(103, "Alen"));
		elist.add(new Employee(104, "Bob"));
		elist.add(new Employee(105, "John Doe"));
	}
	
	public List<Employee> findAll() {
		return elist;
	}
	
	//Create Or Update two in one
	public Employee save(Employee e) {
		//find the e if already exists
		boolean exists = elist.contains(e);
		if(exists) {
			// find the position of the employee object using e.getEmpId()
			int position = elist.indexOf(e);
			elist.set(position, e);
		} else {
			elist.add(e);
		}
		return e;
	}
	
	//delete method
	public void deleteById(int empId) {
		elist = elist.stream().filter(e->e.getEmpId()!=empId)
				.collect(Collectors.toList());
//		other way
//		for (Employee employee : elist) {
//	        if (employee.getEmpId() == empId) {
//	            elist.remove(employee);
//	            break;
//	        }
//	    }
	}
	
	//find by id method
	public Employee findById(int empId) {
		Employee temp = elist.stream()
					.filter(e->e.getEmpId()==empId)
					.findFirst()
					.orElse(null);
		return temp;
	}
	
}
