package com.datajpa.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.datajpa.restapi.dao.EmployeeDAO;
import com.datajpa.restapi.server.Employee;

@RestController // this is equal to @Controller + @ResponseBody
@RequestMapping("/api/employees")
public class EmployeeController {
	
	@Autowired
	private EmployeeDAO edao;
	
	@GetMapping
	public List<Employee> findAll() {
		return edao.findAll();
	}
	
	@PostMapping
	public Employee addEmployee(@RequestBody Employee employee) {
		return edao.save(employee);
	}
	

	@PutMapping
	public Employee updateEmployee(@RequestBody Employee employee) {
		return edao.save(employee);
	}
	
	@DeleteMapping("/{empId}")
	public void deleteById(@PathVariable("empId")int empId) {
		edao.deleteById(empId);
	}
	
	@GetMapping("/{empId}")
	public Employee findById(@PathVariable("empId")int empId) {
		return edao.findById(empId);
	}
}
