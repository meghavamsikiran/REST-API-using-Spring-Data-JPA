package com.datajpa.restapi.io;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.datajpa.restapi.server.Employee;

public class EmployeeRestClient {
	static RestTemplate template = new RestTemplate();
	static String url="http://localhost:8000/spring-datajpa-using-rest-api/api/employees";
	
	public static void main(String[] args) {
		addEmpUsingEntity();
		findAll();
	}
	
	public static void findAll() {
		Employee e[]= template.getForObject(url, Employee[].class);
		for(Employee temp : e) {
			System.out.println(temp.getEmpId()+" : "+temp.getEmpName());
		}
	}
	
	public static void addEmployee() {
		Employee added = template.postForObject(url, new Employee(123, "from main"), Employee.class);
		System.out.println("===> Record Added Successfully!");
	}
	
	public static void findById() {
		String tempUrl = url;
		tempUrl += "/{empId}";
		Map<String, Integer> paramMap = new HashMap();
		paramMap.put("empId", 101);
		Employee search = template.getForObject(tempUrl, Employee.class, paramMap);
		System.out.println(search.getEmpId()+" : "+search.getEmpName());
	}
	
	public static void deleteById() {
		String tempUrl = url;
		tempUrl+= "/{empId}";
		Map<String, Integer> paramMap = new HashMap();
		paramMap.put("empId", 105);
		template.delete(tempUrl, paramMap);
		System.out.println("===> Now fetching all the records after delete..");
		findAll();
	}
	
	public static void updateEmployee() {
		template.put(url, new Employee(102, "updateEmpName"));
		System.out.println("===> Record Updated...printing all records after update");
		findAll();
	}
	
	public static void addEmpUsingEntity() {
		ResponseEntity<Employee> added = template.postForEntity(url, new Employee(556, "newAddEntity"), Employee.class);
		MediaType mt = added.getHeaders().getContentType();
		System.out.println(mt);
		System.out.println("===> Record Added Successfully!");
	}
}
